Decompression from Zig streaming.
